# Freedom Metal Machine Compatibility Library

Documentation for the Freedom Metal library [can be found here](https://sifive.github.io/freedom-metal-docs/).

